        <a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Return to top" data-toggle="tooltip" data-placement="left">
            <i class="livicon" data-name="plane-up" data-size="18" data-loop="true" data-c="#fff" data-hc="white"></i>
        </a>
        <!-- global js -->
        <script src="<?PHP echo base_url(); ?>asset/template/js/app.js" type="text/javascript"></script>
        <!-- end of global js -->
        <!-- begining of page level js -->
        <!-- EASY PIE CHART JS -->
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/jquery.easy-pie-chart/js/easypiechart.min.js"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/jquery.easy-pie-chart/js/jquery.easypiechart.min.js"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/js/jquery.easingpie.js"></script>
        <!--end easy pie chart -->
        <!--for calendar-->
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/moment/js/moment.min.js" type="text/javascript"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/fullcalendar/js/fullcalendar.min.js" type="text/javascript"></script>
        <!--   Realtime Server Load  -->
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/flotchart/js/jquery.flot.js" type="text/javascript"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/flotchart/js/jquery.flot.resize.js" type="text/javascript"></script>
        <!--Sparkline Chart-->
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/sparklinecharts/jquery.sparkline.js"></script>
        <!-- Back to Top-->
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/countUp.js/js/countUp.js"></script>
        <!--   maps -->
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/bower-jvectormap/js/jquery-jvectormap-1.2.2.min.js"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/bower-jvectormap/js/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/vendors/chartjs/Chart.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
        <!--  todolist-->
        <script src="<?PHP echo base_url(); ?>asset/template/js/pages/todolist.js"></script>
        <script src="<?PHP echo base_url(); ?>asset/template/js/pages/dashboard.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/jquery.dataTables.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/jeditable/js/jquery.jeditable.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/dataTables.bootstrap.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/dataTables.buttons.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/dataTables.colReorder.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/dataTables.responsive.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/dataTables.rowReorder.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/buttons.colVis.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/buttons.html5.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/buttons.print.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/buttons.bootstrap.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/pdfmake.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/vfs_fonts.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/vendors/datatables/js/dataTables.scroller.js"></script>
        <script type="text/javascript" src="<?PHP echo base_url(); ?>asset/template/js/pages/table-advanced.js"></script>                                                                                                                                                                                                                                                        
        <!-- end of page level js -->
    </body>

</html>
